import os

def hello():
    print("hello note")
class Mission(list):
    title = None
    description = None
    deadline = None
    priority = None
    listvirtue:list = ["title","description","deadline","priority"]
    def __init__(self, title = None, description = None, deadline:float = None, priority:int = None):
        self.title = title
        self.description = description
        self.deadline = deadline
        self.priority = priority

    def __str__(self):
        return f"{self.title} "
class MissionManager(Mission):
    def write_mission(self,title,description,deadline,priority):
        self = Mission(title,description,deadline,priority)
        file_path = f"D:\\note\\{self.title}.txt"
        with open(file_path, "a", encoding="UTF-8") as df:
            df.write(self.title + ":\n" + self.description + "\n" + str(self.deadline) + "\n" + str(self.priority) + "\n")
            df.flush()
            df.close()
        print(f"{self.title} 已创建!")
        return self
        # 这个函数可以将任务写入txt文件。

    def read_mission(self):
        print(f"任务标题:{self.title}\n",f"任务描述:{self.description}\n",
              f"截止日期:{self.deadline}\n",f"优先级:{self.priority}\n")
        #这个函数可以读取对象。

    def read_mission_from_file(self):
        file_path = f"D:\\note\\{self.title}.txt"
        with open(file_path, "r", encoding="UTF-8") as df:
            for i in range(4):
                print(self.listvirtue[i],":",end = '')
                print(df.readline())
            df.close()
        #这个函数可以将txt文件中的类属性输出。

    def del_mission(self):
        del self
        print(f"{self} 已删除!")
        #这个函数可以删除python中的对象。

    def del_mission_from_file(self):
        file_path = f"D:\\note\\{self.title}.txt"
        file_pathh = f"D:\\note\\rubbish.txt"
        with open(file_path, "w", encoding="UTF-8") as df:
            df.write("")
            df.close()
        os.rename(file_path, file_pathh)
        #这个函数可以将txt文件中的内容清空。

    def change_mission(self,title,description,deadline,priority):
        self = Mission(title,description,deadline,priority)
        print(f"{self} has been changed!" )
        return self
        #这个函数可以改写python对象属性。

    def change_mission_from_file(self,title,description,deadline,priority):
        file_path = f"D:\\note\\{self.title}.txt"
        self = Mission(title,description,deadline,priority)
        # print("已进入函数")
        with open(file_path, "w", encoding="UTF-8") as df:
            df.write("")
            # print("已清空")
            df.write(self.title + ":\n" + self.description + "\n" + str(self.deadline) + "\n" + str(self.priority) + "\n")
            df.flush()
            df.close()
            # print("已重写")
        file_pathh = f"D:\\note\\{self.title}.txt"
        os.rename(file_path,file_pathh)
        return self

    def change_mission_from_files(self,title,description,deadline,priority):
        Mission.del_mission_from_file(self)
        Mission.write_mission(self,title,description,deadline,priority)
class FileHandler(Mission, list):
    state = None
    list1:list = None
    list2:list = None
    list3:list = None

    def __init__(self, title, description, deadline, priority):
        super().__init__(title, description, deadline, priority)

    def mark_completed(self):
        self.state = "completed"
        print(f"The mission '{self.title}' is now completed.")

    def mark_uncompleted(self):
        self.state = "uncompleted"
        print(f"The mission '{self.title}' is now uncompleted.")

    # def sort_by_priority(self):
    #     if self.priority == 1:
    #         self.list1.append(self)
    #     elif self.priority == 2:
    #         self.list2.append(self)
    #     else:
    #         self.list3.append(self)
    #
    # def open_mission(sort_by_priority):
    #     folder_path = "D:\\note"
    #     txt_files = [f for f in os.listdir(folder_path) if f.endswith('.txt')]
    #     print(txt_files)
    #     for file_name in txt_files:
    #         file_path = os.path.join(folder_path, file_name)
    #         print(file_path)
    #         with open(file_path, "r", encoding="UTF-8") as df:
    #             title = df.readline().strip().rstrip(':')
    #             description = df.readline().strip()
    #             deadline = df.readline().strip()
    #             priority = int(df.readline().strip())
    #             mission = Mission(title, description, deadline, priority)
    #             print(mission.priority)
    #             sort_by_priority(mission)