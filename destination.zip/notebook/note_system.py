import os
from time import sleep
from my_note.hello_note import Mission
from my_note.hello_note import MissionManager
from my_note.hello_note import FileHandler

if __name__ == "__main__":
    list1,list2,list3 = [],[],[]
    def open_mission():
        folder_path = "D:\\note"
        txt_files = [f for f in os.listdir(folder_path) if f.endswith('.txt')]
        # print(txt_files)
        for file_name in txt_files:
            file_path = os.path.join(folder_path, file_name)
            # print(file_path)
            with open(file_path, "r", encoding="UTF-8") as df:
                title = df.readline().strip().rstrip(':')
                description = df.readline().strip()
                deadline = float(df.readline().strip())
                priority = int(df.readline().strip())
                mission = Mission(title, description, deadline, priority)
                # print(mission.priority)
                sort_by_priority(mission)

    def sort_by_priority(mission:Mission):
        # print(mission)
        if mission.priority == 1:
            list1.append(mission)
        elif mission.priority == 2:
            list2.append(mission)
        else:
            list3.append(mission)

    def create_mission():
        mission = Mission()
        mission = MissionManager.write_mission(mission,
                                               input("任务标题:"),
                                               input("任务描述:"),
                                               input("截止日期(例：5.07表示五月七号):"),
                                               input("优先级(填1~3):"))
        sort_by_priority(mission)

    def change_mission():
        task = input("请输入您想修改的任务的标题：")
        title = input("任务标题:")
        description = input("任务描述:")
        deadline = input("截止日期:")
        for i in list1:
            if task == i.title:
                print("正在修改...")
                sleep(5)
                MissionManager.change_mission_from_file(i, title, description, deadline,priority = 1)
                break
        for i in list2:
            if task == i.title:
                print("正在修改...")
                sleep(5)
                MissionManager.change_mission_from_file(i, title, description, deadline, priority = 2)
                break
        for i in list3:
            if task == i.title:
                print("正在修改...")
                sleep(5)
                MissionManager.change_mission_from_file(i, title, description, deadline, priority = 3)
                break
        print(f"{task} 已改为 {title}")

    def maopao(list1:list):
        temp:float = 0
        for i in range(len(list1)):
            for j in range(i+1,len(list1)):
                if list1[i].deadline >= list1[j].deadline:
                    temp = list1[i]
                    list1[i] = list1[j]
                    list1[j] = temp

    def show_mission(list1 = list1, list2 = list2, list3 = list3):
        maopao(list1)
        maopao(list2)
        maopao(list3)
        print("优先级为“3”的任务：")
        for i in list3:
            # print(i)
            MissionManager.read_mission(i)
            print("_"*25)
        print("="*35)
        print("优先级为“2”的任务：")
        for i in list2:
            # print(i)
            MissionManager.read_mission(i)
            print("_"*25)
        print("="*35)
        print("优先级为“1”的任务：")
        for i in list1:
            # print(i)
            MissionManager.read_mission(i)
            print("_"*25)
        print("="*35)
    def del_mission():
        title = input("请输入要删除的任务标题:")
        path_file = f"D:\\note\\{title}.txt"
        os.remove(path_file)
        print(f"{title} 已删除")

    def main():
        open_mission()
        # print(list1)
        # print(list2)
        # print(list3)
        print("查看任务请输入“1”。\n添加新任务请输入“2”。\n修改任务请输入“3”。\n删除任务请输入“4”。\n退出程序请输入“0”。")
        judge = int(input("请输入："))
        if judge == 1:
            show_mission()
        if judge == 2:
            create_mission()
        if judge == 3:
            change_mission()
        if judge == 4:
            del_mission()
        if judge == 0:
            exit()
        list1.clear()
        list2.clear()
        list3.clear()
        main()
    main()






























